##
## This script is meant to start with RGeostats
##
{
liste.initiale = ls()
on.exit(demo.clean(liste.initiale))
par(ask=FALSE)

db = db.create(nx=c(100,100))
model = model.create(vartype = melem.name(4), range = 30)
db = simtub(, db, model, nbtuba = 1000)
plot(db,title="Check is successful!")
}
