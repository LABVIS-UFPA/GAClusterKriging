# ICES Cooperative Research Report
# Handbook of Geostatistics in R for fisheries and marine ecology
#
# Based on 
# ICES Training Course
# Application of Geostatistics to analyse spatially explicit Survey data
# in an Ecosystem Approach
# December 2013-2014, Fontainebleau, Centre de Geosciences, Mines ParisTech 
#
# chapter:      Indices of spatial distribution
# Author:       Mathieu Woillez, Ifremer
# Date:         14/01/2015
# R:            3.0.2
# RGeostats:    11.0.2

{
liste.initiale = ls()
on.exit(demo.clean(liste.initiale))
par(ask=FALSE)

                                        # Load libraries
library(mapdata)
library(maps)
projec.toggle(0,verbose=FALSE)

                                        # Loading data
rg.load("Demo.hake.bob.db.data","db.data")
rg.load("Demo.hake.bob.poly.data","poly.data")

                                        # Visualizing the data set
plot(db.data,title="Age-0 hake densites",
     asp=1/cos(mean(db.extract(db=db.data,names="x2"))*pi/180),
     xlim=c(-11,0),ylim=c(43,49),inches=4,pos.legend=3,
     zmin=0,zmax=c(db.stat(db.data,"maxi")),include.bounds=FALSE)
plot(poly.data,col=8,add=T)
map("worldHires",add=T,fill=T,col=8)
demo.pause("Display information")

                                        # Define the projection 
projec.define(projection="mean", db=db.data, flag.update=TRUE)
plot(db.data,title="Age-0 hake densites (in projected space)",asp=1,
     xlim=c(-300,150),ylim=c(-200,150),inches=4,pos.legend=3,
     ,zmin=0,zmax=c(db.stat(db.data,"maxi")),include.bounds=FALSE)
plot(poly.data,col=8,add=T)
demo.pause("Display information (projected space)")

                                        # Center of gravity, Inertia and
                                        # Isotropy of the fish densities
plot(db.data,title="Center of gravity and inertia of densities and samples",
     asp=1,xlim=c(-300,150),ylim=c(-200,150),inches=5)
plot(poly.data,col=8,add=T)
cgi = SI.cgi(db.data,flag.plot=T,flag.inertia=T,col=2)
res = projec.invert(cgi$center[1],cgi$center[2])
cat("Age-0 hake densities:\n")
cat("Center of gravity = ",res$x,res$y,"\n")
cat("Inertia =           ",cgi$inertia,"\n")
cat("Isotropy =          ",cgi$iso,"\n")

                                        # Center of gravity, Inertia and
                                        # Isotropy of the samples
plot(db.add(db.data,S=1),add=TRUE,col=1,inches=5,pch="+")
cgi = SI.cgi(db.add(db.data,S=A0>=0),flag.plot=T,flag.inertia=T,col=1)
res = projec.invert(cgi$center[1],cgi$center[2])
cat("Sample locations:\n")
cat("Center of gravity = ",res$x,res$y,"\n")
cat("Inertia =           ",cgi$inertia,"\n")
cat("Isotropy =          ",cgi$iso,"\n")
demo.pause("Center of gravity & Inertia")

                                        # Global index of collocation (A0 & A1)
gic = SI.gic(db1=db.data,db2=db.data,name1="A0",name2="A1",
       flag.plot=T,flag.inertia=T,asp=1,inches=5,title="A0 and A1",
       col1="red",col2="blue")
cat("Global index of collocation = ",gic,"\n")
plot(poly.data,col=8,add=T)
demo.pause("Global index of collocation")

                                        # Local index of collocation (A0 & A1)
lic = SI.lic(db.data,name1="A0",name2="A1")
cat("Local index of collocation = ",lic,"\n")
plot(db.locate(db.data,"A0",loctype="z"),title="",col=2,asp=1,
     xlim=c(-300,150),ylim=c(-200,150),inches=5)
plot(db.locate(db.data,"A1",loctype="z"),title="",col=4,add=TRUE,inches=5)
plot(poly.data,col=8,add=TRUE)
title("Age-0 and age-1 hake densities")
demo.pause("Local index of collocation")

                                        # Microstructure index
micro = SI.micro(db.data,h0=10,pol=poly.data,dlim=50,ndisc=400)
cat("Microstructure Index = ",micro,"\n")

                                        # Abundance index, positive area,
                                        # Equivalent area and spreading area
stats = SI.stats(db.data,flag.plot=T)
cat("Abundance Index = ",stats$totab,"\n")
cat("Positive area =   ",stats$parea,"\n")
cat("Equivalent area = ",stats$eqarea,"\n")
cat("Spreading area =  ",stats$sparea,"\n")
demo.pause("Different indices")

                                        # Number of spatial patches
patches = SI.patches(db.data, D.min = 100, A.min = 10)
plot(poly.data,col=8,add=T,flag.proj=FALSE,main="Spatial patches")
demo.pause("Spatial patches")
}
